const foods = [
 {id:1,name:"Margherita Pizza",category:"Pizza",restaurant:"Oven Story",description:"Classic cheese, tomato & fresh basil",price:149,rating:4.8,time:"25–30 min",badge:"Bestseller",image:"https://images.unsplash.com/photo-1579751626657-72bc17010498?auto=format&fit=crop&w=900&q=80"},
 {id:2,name:"Crispy Chicken Burger",category:"Burger",restaurant:"Burger Barn",description:"Crunchy chicken, lettuce & house sauce",price:179,rating:4.7,time:"20–25 min",badge:"Popular",image:"https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=900&q=80"},
 {id:3,name:"Paneer Tikka Bowl",category:"Indian",restaurant:"Spice Route",description:"Smoky paneer with fragrant basmati rice",price:199,rating:4.9,time:"25–35 min",badge:"Top rated",image:"https://images.unsplash.com/photo-1631452180519-c014fe946bc7?auto=format&fit=crop&w=900&q=80"},
 {id:4,name:"Veg Hakka Noodles",category:"Chinese",restaurant:"Wok This Way",description:"Wok-tossed noodles with crunchy vegetables",price:159,rating:4.6,time:"20–30 min",badge:"Chef's pick",image:"https://images.unsplash.com/photo-1585032226651-759b368d7246?auto=format&fit=crop&w=900&q=80"},
 {id:5,name:"Chocolate Lava Cake",category:"Dessert",restaurant:"Sweet Spot",description:"Warm chocolate cake with a gooey centre",price:99,rating:4.9,time:"15–20 min",badge:"Sweet treat",image:"https://images.unsplash.com/photo-1624353365286-3f8d62daad51?auto=format&fit=crop&w=900&q=80"},
 {id:6,name:"Mango Cooler",category:"Drinks",restaurant:"Fresh Press",description:"Chilled mango, citrus & a hint of mint",price:79,rating:4.5,time:"10–15 min",badge:"Refreshing",image:"https://images.unsplash.com/photo-1546173159-315724a31696?auto=format&fit=crop&w=900&q=80"}
];
let activeCategory = "All";
let searchTerm = "";
let cart = [];
let saved = new Set();
const grid = document.getElementById("foodGrid");
const cartDrawer = document.getElementById("cartDrawer");
const overlay = document.getElementById("overlay");
const toast = document.getElementById("toast");
document.getElementById("year").textContent = new Date().getFullYear();

function showToast(message){
 toast.textContent = message; toast.classList.add("show");
 clearTimeout(showToast.timer); showToast.timer = setTimeout(()=>toast.classList.remove("show"),2400);
}
function renderFoods(){
 const sort = document.getElementById("sortSelect").value;
 let filtered = foods.filter(f => (activeCategory === "All" || f.category === activeCategory) &&
   (f.name + " " + f.restaurant + " " + f.description).toLowerCase().includes(searchTerm.toLowerCase()));
 if(sort === "rating") filtered.sort((a,b)=>b.rating-a.rating);
 if(sort === "price") filtered.sort((a,b)=>a.price-b.price);
 grid.innerHTML = filtered.map(f=>`
  <article class="food-card">
   <div class="food-image"><img src="${f.image}" alt="${f.name}" loading="lazy"><span class="food-badge">${f.badge}</span>
    <button class="heart-button ${saved.has(f.id)?"saved":""}" data-save="${f.id}" aria-label="${saved.has(f.id)?"Remove from":"Add to"} favorites">${saved.has(f.id)?"♥":"♡"}</button>
   </div>
   <div class="food-info"><div class="food-title-row"><h3>${f.name}</h3><span class="rating"><span>★</span> ${f.rating}</span></div>
    <p class="food-description">${f.restaurant} · ${f.description}</p>
    <div class="food-bottom"><div class="food-price">₹${f.price} <small>· ${f.time}</small></div><button class="add-button" data-add="${f.id}">+ Add</button></div>
   </div>
  </article>`).join("");
 document.getElementById("emptyState").classList.toggle("hidden",filtered.length>0);
}
function addToCart(id){
 const item = cart.find(i=>i.id===id);
 if(item) item.qty++; else cart.push({id,qty:1});
 renderCart(); showToast(`${foods.find(f=>f.id===id).name} added to cart`);
}
function changeQty(id,delta){
 const item=cart.find(i=>i.id===id); if(!item)return;
 item.qty+=delta; if(item.qty<=0)cart=cart.filter(i=>i.id!==id);
 renderCart();
}
function renderCart(){
 const count=cart.reduce((sum,i)=>sum+i.qty,0);
 document.getElementById("cartCount").textContent=count;
 document.getElementById("drawerCount").textContent=`(${count})`;
 const itemsEl=document.getElementById("cartItems");
 itemsEl.innerHTML=cart.map(i=>{const f=foods.find(x=>x.id===i.id);return `<div class="cart-item"><img src="${f.image}" alt=""><div><h3>${f.name}</h3><p>₹${f.price*i.qty}</p><div class="quantity"><button data-qty="-1" data-id="${f.id}" aria-label="Decrease quantity">−</button><span>${i.qty}</span><button data-qty="1" data-id="${f.id}" aria-label="Increase quantity">+</button></div></div></div>`}).join("");
 const empty=cart.length===0;
 document.getElementById("cartEmpty").classList.toggle("hidden",!empty);
 document.getElementById("cartBottom").classList.toggle("hidden",empty);
 const subtotal=cart.reduce((sum,i)=>sum+foods.find(f=>f.id===i.id).price*i.qty,0);
 document.getElementById("subtotal").textContent=`₹${subtotal}`;
 document.getElementById("total").textContent=`₹${subtotal+25}`;
}
function openCart(){cartDrawer.classList.add("open");overlay.classList.remove("hidden");cartDrawer.setAttribute("aria-hidden","false");document.body.style.overflow="hidden"}
function closeCart(){cartDrawer.classList.remove("open");overlay.classList.add("hidden");cartDrawer.setAttribute("aria-hidden","true");document.body.style.overflow=""}
grid.addEventListener("click",e=>{
 const add=e.target.closest("[data-add]"); if(add)addToCart(Number(add.dataset.add));
 const save=e.target.closest("[data-save]"); if(save){const id=Number(save.dataset.save);saved.has(id)?saved.delete(id):saved.add(id);renderFoods();showToast(saved.has(id)?"Added to favorites":"Removed from favorites")}
});
document.getElementById("categoryList").addEventListener("click",e=>{
 const btn=e.target.closest("[data-category]");if(!btn)return;
 activeCategory=btn.dataset.category;
 document.querySelectorAll(".category").forEach(b=>b.classList.toggle("active",b===btn));renderFoods();
});
document.getElementById("searchForm").addEventListener("submit",e=>{e.preventDefault();searchTerm=document.getElementById("searchInput").value.trim();renderFoods();document.getElementById("restaurants").scrollIntoView({behavior:"smooth"});});
document.getElementById("searchToggle").addEventListener("click",()=>{document.getElementById("searchInput").focus();document.getElementById("home").scrollIntoView({behavior:"smooth"});});
document.getElementById("sortSelect").addEventListener("change",renderFoods);
document.getElementById("cartOpen").addEventListener("click",openCart);
document.getElementById("cartClose").addEventListener("click",closeCart);
overlay.addEventListener("click",closeCart);
document.getElementById("browseFood").addEventListener("click",()=>{closeCart();document.getElementById("restaurants").scrollIntoView({behavior:"smooth"})});
document.getElementById("cartItems").addEventListener("click",e=>{const b=e.target.closest("[data-qty]");if(b)changeQty(Number(b.dataset.id),Number(b.dataset.qty))});
document.getElementById("copyCoupon").addEventListener("click",async()=>{
 try{await navigator.clipboard.writeText("FIRSTBITE");showToast("Coupon code copied!")}catch{showToast("Use coupon code: FIRSTBITE")}
});
document.getElementById("checkoutButton").addEventListener("click",()=>showToast("Demo only — connect a checkout service for real payments."));
document.addEventListener("keydown",e=>{if(e.key==="Escape")closeCart()});
renderFoods();renderCart();
