# Foodie — Food Delivery UI/UX Project

A responsive food delivery website prototype created for a college UI/UX project using HTML, CSS and JavaScript.

## Features
- Responsive layout for desktop and mobile
- Search dishes by name, restaurant or description
- Filter menu by category
- Sort dishes by rating or price
- Add/remove quantities in a cart drawer
- Favorite button interactions
- Coupon copy interaction
- Demo checkout message (no real payments)
- Accessible labels and keyboard-friendly cart closing

## Run locally
1. Download and extract `foodie-food-delivery.zip`.
2. Open the `foodie-food-delivery` folder.
3. Double-click `index.html` to open it in a browser.
4. For a local development server, open the folder in VS Code and use the Live Server extension.

Images and Google Fonts are loaded from external URLs, so an internet connection is needed for those assets.

## Publish with GitHub Pages
1. Sign in at https://github.com and create a **public** repository, for example `foodie-food-delivery`.
2. Upload `index.html`, `style.css`, `script.js`, and this `README.md` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch **main** and folder **/(root)**, then click **Save**.
6. Wait for GitHub Pages to publish; your website URL will appear in the Pages section. It usually looks like `https://YOUR-USERNAME.github.io/foodie-food-delivery/`.

## UI/UX case-study outline for faculty
- **Problem:** Users want a simple way to discover meals and place an order without friction.
- **Target users:** Students, busy professionals and people ordering meals at home.
- **Design goals:** Clear categories, readable menu cards, visible pricing, quick cart actions and a responsive layout.
- **Primary user flow:** Browse categories → search/filter food → add items → adjust cart → demo checkout.
- **Visual system:** Orange primary accent, charcoal text, warm off-white surfaces, rounded cards and Poppins/DM Sans typography.
- **Scope note:** This is a front-end prototype. Authentication, live restaurant data, order tracking and payment processing are not connected.
